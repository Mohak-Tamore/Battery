from django.contrib import admin
from api.models import *

# Register your models here.

admin.site.register(Station)
admin.site.register(Battery)
admin.site.register(History)